document.addEventListener('DOMContentLoaded', function() {
    console.log('Loja Virtual carregada!');
});
