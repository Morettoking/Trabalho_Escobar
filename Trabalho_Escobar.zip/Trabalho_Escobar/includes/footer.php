<footer>
    <hr>
    <p>&copy; <?= date('Y') ?> Loja Virtual - Todos os direitos reservados.</p>
</footer>
</body>
</html>
